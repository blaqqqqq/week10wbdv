@extends("template.main")

@section("title", "Welcome to Our Store")

@section("body")
  <!-- Hero Section -->
  <div class="bg-primary text-white py-5">
    <div class="container py-5">
      <h1>
        Discover the Latest <br />
        Products & Brands Here
      </h1>
      <p>
        Find Trendy Products at Affordable Prices!
      </p>
      <button type="button" class="btn btn-outline-light">
        Explore More
      </button>
      <button type="button" class="btn btn-light shadow-0 text-primary pt-2 border border-white">
        <span class="pt-1">Shop Now</span>
      </button>
    </div>
  </div>
  <!-- End Hero Section -->

    <!-- Featured Products -->
    <section>
    <div class="container my-5">
        <header class="mb-4">
        <h3>New Arrivals</h3>
        </header>

        <div class="row">
        {{-- @dd($newProducts) --}}
        @foreach ($newProducts as $product)
        <div class="col-lg-3 col-md-6 col-sm-6 d-flex">
            <a href="{{ url("/product/{$product->id}-{$product->name}") }}">
                <div class="card w-100 my-2 shadow-2-strong">
                <img src="{{ $product->image }}" class="card-img-top" style="aspect-ratio: 1 / 1" />
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ $product->name }}</h5>
                    <p class="card-text">${{ $product->price }}</p>
                    <div class="card-footer d-flex align-items-end pt-3 px-0 pb-0 mt-auto">
                    <a href="#!" class="btn btn-primary shadow-0 me-1">Add to Bag</a>
                    <a href="#!" class="btn btn-light border px-2 pt-2 icon-hover"><i class="fas fa-heart fa-lg text-secondary px-1"></i></a>
                    </div>
                </div>
                </div>
            </a>
        </div>
        @endforeach
        </div>
    </div>
    </section>
    <!-- End Featured Products -->

    <!-- Why Choose Us Section -->
    <section class="mt-5" style="background-color: #f5f5f5;">
    <div class="container text-dark pt-3">
        <header class="pt-4 pb-3">
        <h3>Why Shop With Us?</h3>
        </header>

        <div class="row mb-4">
        <div class="col-lg-4 col-md-6">
            <figure class="d-flex align-items-center mb-4">
            <span class="rounded-circle bg-white p-3 d-flex me-2 mb-2">
                <i class="fas fa-camera-retro fa-2x fa-fw text-primary floating"></i>
            </span>
            <figcaption class="info">
                <h6 class="title">Affordable Prices</h6>
                <p>Enjoy great deals on quality products!</p>
            </figcaption>
            </figure>
            <!-- itemside // -->
        </div>
        <!-- col // -->
        <div class="col-lg-4 col-md-6">
            <figure class="d-flex align-items-center mb-4">
            <span class="rounded-circle bg-white p-3 d-flex me-2 mb-2">
                <i class="fas fa-star fa-2x fa-fw text-primary floating"></i>
            </span>
            <figcaption class="info">
                <h6 class="title">Top-notch Quality</h6>
                <p>Discover products made with premium materials!</p>
            </figcaption>
            </figure>
            <!-- itemside // -->
        </div>
        <!-- col // -->
        <div class="col-lg-4 col-md-6">
            <figure class="d-flex align-items-center mb-4">
            <span class="rounded-circle bg-white p-3 d-flex me-2 mb-2">
                <i class="fas fa-plane fa-2x fa-fw text-primary floating"></i>
            </span>
            <figcaption class="info">
                <h6 class="title">Worldwide Shipping</h6>
                <p>Get your favorite items delivered to your doorstep!</p>
            </figcaption>
            </figure>
            <!-- itemside // -->
        </div>
        <!-- col // -->
        </div>
    </div>
    <!-- container end.// -->
    </section>
    <!-- End Why Choose Us Section -->
@endsection
